<template>
<div>
  <el-head>
    <div >
      <h1 style="font-weight: lighter;font-size: 20px;margin-left: 30px;text-align: left">第2步（共三步）</h1>
      <h1 style="font-size: xxx-large;text-align: left;margin-left: 20px;margin-top: 0;padding: 0">选择房价</h1>
      <div class="box1"style="margin: 5px">
      <div style="text-align: left;margin-left: 20px;padding: 15px;font-size: larger;font-weight: bold;color: rgba(254,243,255,0.71)">18 岁以下儿童可免费与父母共用一张睡床。三人住宿时，酒店将对增加的宾客收取加床和/或早餐费。18 岁及以上宾客视为成人，预订时请计入成人数量。
      </div></div>
    </div>
  </el-head>

  <div  style="text-align: left;margin: 20px"><img src="@/assets/king-executive-harbour-suite.webp">
    <div style="width:400px;height:300px;border-radius: 10px;background-color:whitesmoke;float: right;margin-right: 75px;margin-top: 20px;padding: 50px">
      <h1 style="text-align: left;font-size: 20px">请选择人数（单人房只能一个成人，双人房只能两个成人）</h1>
      <el-radio-group v-model="df.number">
        <el-radio-button label="1"></el-radio-button>
        <el-radio-button label="2"></el-radio-button>
        <el-radio-button label="3"></el-radio-button>
        <el-radio-button label="4"></el-radio-button>
      </el-radio-group>
      <el-input
          placeholder="请输入宾客名字"
          v-model="df.name"
          clearable>
      </el-input>
      <el-input
          placeholder="请输入身份证"
          v-model="df.card"
          clearable>
      </el-input>
      <el-input
          placeholder="请输入电话"
          v-model="df.phone"
          clearable>
      </el-input>
      <el-input
          placeholder="请输入联系地址"
          v-model="df.address"
          clearable>
      </el-input>
      <el-button style="height: 60px;width: 350px;margin-top: 20px;font-size: larger;font-weight: bold" type="primary" @click="create">预定房价750$起</el-button>
      </div>

  </div>
</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "choose",
  data(){
    return {
   df:{
     name:'',
     card:'',
     phone:'',
     address:'',
     number: {
       radio1: '1',
       radio2: '2',
       radio3: '3',
       radio4: '4'
     }
   },

    }  },
  methods:{
    create(){
      request.put("/Df/add",this.df).then(res=>{
        if(res.code==='200'){
          this.$notify.success("预定成功")
          this.$router.push('/success')
        }})
    }
  }
}
</script>

<style scoped>
.box1 {
  border: 2px solid black; /* 同时设置边框宽度、样式和颜色 */
  background-color: #8cc5ff;
  border-radius: 5px;

}
</style>