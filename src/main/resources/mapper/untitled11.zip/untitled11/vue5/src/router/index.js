import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const routes = [
  {
    path:'/',
    name:'login',
    component:()=>import('@/views/login/login')
  }, {
    path:'/1',
    name:'login',
    component:()=>import('@/views/login/1')
  },
  {
    path:'/layout',
    name:'layout',
    component:()=>import('@/views/admin/layout'),
    children:[
        {
      path: '/TF',
      name: 'TF',
      component: () => import('@/views/admin/TF')
    },
      {
        path: '/YD',
        name: 'YD',
        component: () => import('@/views/admin/YD')
      },
      {
        path: '/PL',
        name: 'PL',
        component: () => import('@/views/admin/PL')
      },
      {
        path: '/FJ',
        name: 'FJ',
        component: () => import('@/views/admin/FJ')
      },{
        path: '/GLY',
        name: 'GLY',
        component: () => import('@/views/admin/GLY')
      },
      {
        path: '/room',
        name: 'room',
        component: () => import('@/views/admin/Room')
      },
      {
        path: '/add',
        name: 'AddAdmin',
        component: () => import('@/views/admin/AddAdmin')
      },
      {
        path: '/updateAdmin',
        name: 'UpdateAdmin',
        component: () => import('@/views/admin/UpdateAdmin.vue'),
      },  {
        path: '/updateRoom',
        name: 'UpdateRoom',
        component: () => import('@/views/admin/UpdateRoom.vue'),
      },
      {
        path: '/addYd',
        name: 'AddYD',
        component: () => import('@/views/admin/AddYD'),
      }
    ]
  },
  {
    path: '/DF',
    name:'DF',
    component: ()=>import('@/views/DF/DF'),
    },

      {
        path: '/choose',
        name: 'Choose',
        component: () => import('@/views/DF/choose'),
      },
  {
    path: '/choose1',
    name: 'Choose',
    component: () => import('@/views/DF/choose1'),
  },
  {
    path: '/choose2',
    name: 'Choose',
    component: () => import('@/views/DF/choose2'),
  },
  {
    path: '/success',
        name: 'success',
      component: () => import('@/views/DF/success'),
  },
  {
    path: '/yhpl',
    name: 'YHPL',
    component: () => import('@/views/DF/YHPL'),
  }


  ,
  {
    path: "*",
    component:() => import('@/views/login/404')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
