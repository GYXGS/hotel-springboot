<template>
  <div>
<div class="bg-image":style="{ 'background-image': 'url(' + imageUrl + ')' }">
<div style="text-align: center">
  <img style="margin-top: 20px;"alt="logo_center" src="@/assets/logo_center.png">
</div>
  <div>

      <img style="margin-top: 100px;padding-left: 30px;border-radius: 10px " alt="blackground" src="@/assets/blackground.jpg" class="bottom-image">

  <div style="width:400px;height:300px;border-radius: 10px;background-color:whitesmoke;float: right;margin-right: 75px;margin-top: 100px;padding: 50px">
<div style="margin:25px;text-align: center;font-weight: bold;font-size: 30px;color: rgba(0,0,0,0.71)">登录</div>
    <el-form  >
      <el-form-item  prop="username">
        <el-input placeholder="请输入管理员账号" prefix-icon="el-icon-user" size="medium"  v-model="admin.username" ></el-input>
      </el-form-item>
      <el-form-item  prop="password" >
        <el-input placeholder="请输入密码" show-password prefix-icon="el-icon-lock" size="medium"   v-model="admin.password"></el-input>
      </el-form-item>
      <el-form-item  >
        <el-button style="width: 100%"size="medium" type="primary" @click="login">登录</el-button>
      </el-form-item>
    </el-form>

  </div>
    <div class="fade">
      <h1  style="margin-top: 140px; text-align: center;font-size: 13px">————————————————————————————————————————————————————————————————————————————</h1>
    </div>
    <div style="font-size: 15px;text-align: center">
        <div style="display: inline-block;padding-right: 180px;margin-top: 20px">商务合作<div style="font-weight: bold">0330-123456</div></div>
      <div style="display: inline-block;padding-right:180px">需要帮助<div style="font-weight: bold">0330-220232</div></div>
      <div style="display: inline-block;margin-top: 20px">联系我们<div>VvV国际酒店<div>广东省广州市天河区3023街道VvV集团</div></div></div>

    </div>
  </div>

  </div>
  </div>



</template>

<script>
import request from "@/utils/request";
export default {
  name: "login",
  data(){
    return {
      imageUrl: require('@/assets/背景1.png'),
      admin:{
        username: '',
        password: '',
      }}
  },
  methods:{
    login(){
      request.post('/Admin/login',this.admin).then(res=>{
        if(res.code==='200'){
          this.$notify.success("登陆成功")
          this.$router.push('/layout')
        }
        else {
          this.$notify.error("用户或密码错误")
        }

      })
    },


  }
}
</script>

<style scoped>
.bottom-image {
  z-index: -1;
}
.bg-image{
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  width: 100%;
  height: 100vh;

}
/* 确保该容器被作为全屏背景显示 */
html, body {
  margin:0;
  padding: 0;
  height: 100%;
  overflow: hidden;
}
.fade {
  color: #999;
}
</style>