<template>
  <div style="width: 80%">
    <div style="margin-bottom: 30px">编辑管理员</div>
    <el-form :inline="true" :model="form" label-width="100px">
      <el-form-item label="房间号" prop="room">
        <el-input v-model="form.room" placeholder="请输入房间号"></el-input>
      </el-form-item>
      <el-form-item label="房间类型" prop="type">
        <el-input v-model="form.type" placeholder="请输入房间类型"></el-input>
      </el-form-item>
      <el-form-item label="价格" prop="value">
        <el-input v-model="form.value" placeholder="请输入房间价格"></el-input>
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="form.mean" placeholder="请输入备注"></el-input>
      </el-form-item>
    </el-form>

    <div style="text-align: center; margin-top: 30px">
      <el-button type="primary" @click="save" size="medium">提交</el-button>
    </div>
  </div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: 'EditAdmin',
  data() {
    return {
      form: {}
    }
  },
  created() {
    const id = this.$route.query.id
    request.get("/Fj/" + id).then(res => {
      this.form = res.data
    })
  },
  methods: {
    save() {
      request.put('/Fj/update', this.form).then(res => {
        if (res.code === '200') {
          this.$notify.success('更新成功')
          this.$router.push("/room")
        } else {
          this.$notify.error(res.msg)
        }
      })
    }
  }
}

</script>

