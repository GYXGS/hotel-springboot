<template>
  <div style="text-align: center">
    <div style="font-size: 50px">尊敬的用户，恭喜您</div>
  <div style=" font-size: 100px; ">预定成功</div>
    <div style="align-items: end;font-size: 50px">祝你旅途愉快</div>
    <el-button style="height: 60px;width: 350px;margin-top: 20px;font-size: larger;font-weight: bold" type="primary"@click="$router.push('/YHPL')">点击评论</el-button>
    </div>



</template>

<script>
export default {
  name: "success"
}
</script>

<style scoped>

</style>