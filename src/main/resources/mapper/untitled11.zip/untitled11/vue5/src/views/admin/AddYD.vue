<template><div >
  <el-form>
    <el-form-item label="name">
      <el-input placeholder="请输入名字" v-model="a.name">
      </el-input>
    </el-form-item>

    <el-form-item label="value">
    <el-input placeholder="请输入房间价格" v-model="a.value">
    </el-input>
  </el-form-item>
    <el-form-item label="type">
      <el-input placeholder="请输入种类" v-model="a.type">
      </el-input>
    </el-form-item>
    <el-form-item label="address">
      <el-input placeholder="请输入地址" v-model="a.address">
      </el-input>
    </el-form-item>
      <el-form-item label="card">
        <el-input placeholder="请输入身份证" v-model="a.card">
        </el-input>
      </el-form-item>
        <el-form-item label="phone">
          <el-input placeholder="请输入手机号" v-model="a.phone">
          </el-input>
    </el-form-item>
    <el-form-item label="number">
      <el-input placeholder="请输入入住人数" v-model="a.number">
      </el-input>
    </el-form-item>
    <el-form-item size="medium">
      <el-button type="primary" @click="create">立即预定</el-button>
    </el-form-item>
  </el-form>
</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "AddAdmin",data(){

      return {
        value: '',
        a:{
          type:'',
          value:'',
          name:'',
          phone:'',
          address:'',
          number:'',
          card:'',



        }
      }

  },
  methods: {
    create(){
      request.put("/Df/add",this.a).then(res=>{
      if(res.code==='200'){
        this.$notify.success("添加成功")
        this.$router.push('/YD')
      }})

    }
  }

  }

</script>
<style>
.abc{
display: flex;
}
</style>
<style scoped>

</style>