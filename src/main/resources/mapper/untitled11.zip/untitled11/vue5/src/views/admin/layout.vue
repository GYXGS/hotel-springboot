<template>
  <el-container  style="height: 100%; border: 1px solid #eee"class="ass">
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <el-menu :default-openeds="['1', '3']":default-active="$route.path" router class="el-menu-demo">
        <el-submenu index="1">
          <template slot="title"><i class="el-icon-message"></i>基础信息</template>
          <el-menu-item-group>
            <template slot="title">业务管理</template>
            <el-menu-item index="/FJ">添加房间</el-menu-item>
            <el-menu-item index="/YD">预定管理</el-menu-item>
            <el-menu-item index="/TF">退房管理</el-menu-item>
            <el-menu-item index="/room">房间信息</el-menu-item>
          </el-menu-item-group>
          <el-menu-item-group title="评论">
            <el-menu-item index="/Pl">评论管理</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="3">
          <template slot="title"><i class="el-icon-setting"></i>管理</template>
          <el-menu-item-group>
            <template slot="title">人员管理</template>
            <el-menu-item index="/GLY">管理员信息</el-menu-item>

          </el-menu-item-group>
          <el-menu-item-group title="分组2">
            <el-menu-item index="/add">添加管理员</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <div>
          <el-dropdown>
            <span class="el-dropdown-link" style="cursor: pointer">
            {{ admin.username }}<i class="el-icon-arrow-down el-icon--right"></i>
          </span>

            <el-dropdown-menu slot="dropdown" >
              <el-dropdown-item ><div style="width: 50px; text-align: center" @click="logout" >退出</div></el-dropdown-item>
            </el-dropdown-menu>

          </el-dropdown>
        </div>
      </el-header>

      <el-main>
        <div style="flex: 1;padding: 50px">

          <router-view/>


        </div>

      </el-main>
    </el-container>

  </el-container>

</template>

<script>
export default {
  name: "layout",

}
</script>

<style>
.el-header {
  background-color: #B3C0D1;
  color: #333;
  line-height: 50px;
}

.el-aside {
  color: #333;
}
.ass{
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  width: 100%;
  height: 100vh;

}
/* 确保该容器被作为全屏背景显示 */
html, body {
  margin:0;
  padding: 0;
  height: 100%;
  overflow: hidden;
}
</style>

<script>
import Cookies from 'js-cookie'

export default {

  data() {
    return {
      admin: Cookies.get('Admin') ? JSON.parse(Cookies.get('Admin')) : {}
    }
    // const item = {
    //   id: '2016-05-02',
    //   user: '王小虎',
    //   address: '上海市普陀区金沙江路 1518 弄'
    // };
    // return {
    //   tableData: Array(2).fill(item)
    // }
  },
  methods: {
    logout() {
      // 清除浏览器用户数据
      Cookies.remove('Admin')
      this.$router.push('/')
    }
  }
};
</script>