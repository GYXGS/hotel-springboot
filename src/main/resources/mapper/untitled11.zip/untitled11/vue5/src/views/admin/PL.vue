<template>
  <div>
  <div >
    <el-input style="width: 240px" placeholder="请输入订单号" v-model="params.order1" ></el-input>
    <el-button style="margin-left: 5px" type="primary" @click="load"><i class="el-icon-search" ></i> 搜索</el-button>
    <el-button style="margin-left: 5px" type="warning" @click="reset"><i class="el-icon-refresh" ></i> 重置</el-button>
  </div>
  <el-table  :data="tableData">
    <el-table-column prop="order1" label="订单号" >
    </el-table-column>
    <el-table-column prop="style" label="类型">
    </el-table-column>
    <el-table-column prop="mean" label="评论">
    </el-table-column>
    <el-table-column prop="operate" label="操作">
      <template v-slot="scope">
      <el-popconfirm
          style="margin-left: 5px"
          title="您确定删除这行数据吗？"
          @confirm="del(scope.row.id)"
      >
        <el-button type="danger" slot="reference">删除</el-button>
      </el-popconfirm>
      </template>
    </el-table-column>
  </el-table>
    <!--    分页-->
    <div style="margin-top: 20px">
      <el-pagination
          background
          :current-page="params.pageNum"
          :page-size="params.pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="handleCurrentChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import request from "@/utils/request";

export default {

  name: "PL",
  data(){

return{
  tableData:[],
  total:'',
  params: {
    pageNum: 1,
    pageSize: 10,
    order1: '',
  },
}


  },
  created() {
    this.load()
  },
  methods: {
    load(){
      request.get('/Pl1/page', {
        params: this.params
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data.list
          this.total = res.data.total
        }
      })
    },
    reset() {
      this.params = {
        pageNum: 1,
        pageSize: 8,
        order1: '',
      }
      this.load()
    }
  ,
    // 这是一个 Vue.js 组件中的方法，其主要作用是创建一个弹出框，其中包括一个自定义的标题名称，一些文本内容以及用户点击确定后执行的回调函数。
// 具体来说，代码中的 this.$alert() 是一个由 Vue.js 提供的用于显示警告框的方法。传入的参数包括文本内容、
// 标题名称和一个选项对象，其中 confirmButtonText 属性定义了弹出框中确认按钮的文本内容，
// callback 属性指定用户点击该按钮时执行的回调函数。在回调函数中，
// 使用 this.$message() 方法创建另一个弹出框，显示有关用户操作的信息。
// 其中 type 属性指定了消息的类型（例如“info”、“success”、“warning”等），而 message 属性包含要显示的消息文本，
// 其中使用了 ES6 模板字符串语法将回调函数的 action 参数￥￥到文本中。
//     open() {
//       this.$alert('这是一段内容', '标题名称', {
//         confirmButtonText: '确定',
//         callback: action => {
//           this.$message({
//             type: 'info',
//             message: `action: ${ action }`
//           });
//         }
//       });
//     },
    handleCurrentChange(pageNum) {
      // 点击分页按钮触发分页
      this.params.pageNum = pageNum
      this.load()
    },
    del(id) {
      request.delete("/Pl1/delete/" + id).then(res => {
        if (res.code === '200') {
          this.$notify.success('删除成功')
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    },
  }

}
</script>

<style scoped>

</style>