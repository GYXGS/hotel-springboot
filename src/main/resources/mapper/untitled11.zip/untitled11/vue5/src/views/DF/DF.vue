<template>
  <div>
      <el-head>
        <div >
          <h1 style="font-weight: lighter;font-size: 20px;margin-left: 30px;text-align: left">第1步（共三步）</h1>
          <h1 style="font-size: xxx-large;text-align: left;margin-left: 20px;margin-top: 0">选取房间</h1>
        </div>
        <div class="box1"style="margin: 5px">
          <div style="text-align: left;margin-left: 20px;padding: 15px;font-size: larger;font-weight: bold;color: rgba(254,243,255,0.71)">18 岁以下儿童可免费与父母共用一张睡床。三人住宿时，酒店将对增加的宾客收取加床和/或早餐费。18 岁及以上宾客视为成人，预订时请计入成人数量。
          </div></div>
        <div class="box1"style="margin: 5px">
          <div style="text-align: left;margin-left: 20px;padding: 15px;font-size:larger;font-weight: bold;color: rgba(254,243,255,0.71)">这些客房从今天起可用 1 晚。
          </div></div>
      </el-head>



<div style="text-align: left;margin-left: 20px">找到3种类型房间，我们正在显示...</div>
    <div class="container">
      <div class="box" style="margin: 20px;text-align: center"><img src="@/assets/peak-view-room-2011.webp">
        <el-button style="height: 60px;width: 350px;margin-top: 20px;font-size: larger;font-weight: bold" type="primary" @click="choose2">预定房价750$起</el-button>
      </div>
      <div class="box" style="margin: 20px;text-align: center"><img src="@/assets/superior-room-2012-3mb.webp">
        <el-button style="height: 60px;width: 350px;margin-top: 20px;font-size: larger;font-weight: bold" type="primary"@click="choose1">预定房价850$起</el-button>
      </div>
      <div class="box" style="margin: 20px;text-align: center"><img src="@/assets/king-executive-harbour-suite.webp">
        <el-button style="height: 60px;width: 350px;margin-top: 20px;font-size: larger;font-weight: bold" type="primary"@click="choose">预定房价2000$起</el-button>
      </div>
    </div>
      <div style="flex: 1;padding: 0px">
        <div class="box3"style="margin: 5px">
        <div style="text-align: left; margin-left: 375px;padding: 15px;font-size:x-large;font-weight: bold;color: rgba(254,243,255,0.71)">祝你旅途愉快
          <el-button style="height: 40px;width: 350px;font-size: medium;font-weight: bold" type="primary"@click="$router.push('/YHPL')">点击评论</el-button>
        </div>

        </div>


      </div>
  </div>


</template>

<script>
export default {
  name: "DF",
  data() {
    return {
      active: 0,
    };
  },

  methods: {
    next() {
      if (this.active++ > 2) this.active = 0;
    },
    choose2(){
      this.$router.push('/choose2')
    },
    choose1(){
      this.$router.push('/choose1')
    },
    choose(){
      this.$router.push('/choose')
    }
  },

}
</script>

<style scoped>
.container {
  display: flex;
  justify-content: space-between;
}

.box {
  border: 2px solid #a59e9e;
  width: 30%;
  height: 350px;
}
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid #ccc; /* 添加边框 */
  padding: 10px; /* 添加间距 */
}
.container img {
  max-width: 100%;
  height: auto;
}
.box1 {
  border: 2px solid black; /* 同时设置边框宽度、样式和颜色 */
background-color: #8cc5ff;
  border-radius: 5px;

}
.box3 {
  border: 2px solid black; /* 同时设置边框宽度、样式和颜色 */
  background-color: #8cc5ff;
  border-radius: 5px;

}
</style>




