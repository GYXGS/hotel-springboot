<template>
  <div>
    <!--    搜索-->
    <div >
      <el-input style="width: 240px" placeholder="请输入名称" v-model="params.room"></el-input>
      <el-button style="margin-left: 5px" type="primary" @click="load"><i class="el-icon-search" ></i> 搜索</el-button>
      <el-button style="margin-left: 5px" type="warning" @click="reset"><i class="el-icon-refresh" ></i> 重置</el-button>
      <el-input style="width: 240px" placeholder="请输入名称" v-model="params.type"></el-input>
      <el-button style="margin-left: 5px" type="primary" @click="load1"><i class="el-icon-search" ></i> 搜索</el-button>
      <el-button style="margin-left: 5px" type="warning" @click="reset"><i class="el-icon-refresh" ></i> 重置</el-button>
    </div>
    <!--    data="tableData"是一个用于绑定数据的指令（Directive）。-->
    <!--    其中，tableData是定义在组件（Component）中的数据对象，通过将其与模板中的 data属性绑定来实现将数据渲染到页面上-->
    <el-table  :data="tableData" >
      <el-table-column prop="room" label="房间号" >
      </el-table-column>

      <el-table-column prop="type" label="房间类型">
      </el-table-column>
      <!--      <el-table-column prop="time" label="时间">-->
      <!--      </el-table-column>-->
      <el-table-column prop="value" label="价格">
      </el-table-column>
      <el-table-column prop="mean" label="备注">
      </el-table-column>
      <el-table-column  label="状态">
        <template v-slot="scope">
        <el-switch
              v-model="scope.row.state"
              @change="changeState(scope.row)"
              active-color="#13ce66"
              inactive-color="#ff4949"
        >
          </el-switch>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="230">
        <template v-slot="scope">
          <!--          scope.row 就是当前行数据-->
          <el-button type="primary" @click="$router.push('/updateRoom?id=' + scope.row.id)">编辑</el-button>
          <el-popconfirm
              style="margin-left: 5px"
              title="您确定删除这行数据吗？"
              @confirm="del(scope.row.id)"
          >
            <el-button type="danger" slot="reference">删除</el-button>
          </el-popconfirm>
        </template>
      </el-table-column>
<!--      <el-table-column label="状态" width="230">-->
<!--        <template v-slot="scope">-->
<!--          <el-switch-->
<!--              v-model="scope.row.status"-->
<!--              @change="changeStatus(scope.row)"-->
<!--   1111   v-model="scope.row.status"：表示将组件（这里应该是<el-switch>）中的状态值绑定到 vue 实例的一个叫做status的属性上。这里的 scope.row 是当前操作行的数据对象，在一个vue表格组件中经常出现，表示当前所操作的行数据。可以将这个组件渲染在表格的每一行当中，因此需要通过 scope.row 选择当前的行数据。-->
<!--     1111 @change="changestatus(scope.row)"：表示在组件发生改变时（即<el-switch>被打开或关闭时），触发了一个名为changestatus()的自定义事件，并给该事件传递了当前行数据对象。这个事件是响应式的方式实现，在 vue 中，我们可以声明一个方法来处理这个事件，通常会把操作后得到的结果保存到状态管理器 (如 vuex) 中，或者通过 ajax 发送到服务器来更新数据库。-->
<!--              active-color="#13ce66"-->
<!--              inactive-color="#ff4949">-->
<!--          </el-switch>-->
<!--        </template>-->
<!--      </el-table-column>-->
    </el-table>
    <!--    分页-->
    <div style="margin-top: 20px">
      <el-pagination
          background
          :current-page="params.pageNum"
          :page-size="params.pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="handleCurrentChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import request from "@/utils/request";
export default {
  name: "Room",
  data(){
    return{
        value: '100',
      tableData:[],
      total:0,
      params: {
        pageNum: 1,
        pageSize: 8,
        room: '',
        type:''
      },
      // dialogFormVisible: false,
      rules:{}
    }
  },
  created() {
    this.load()
  },
//   created() 选项是 vue.js 组件中的一个生命周期钩子函数，在组件实例被创建并初始化后立即调用，这时候可以访问到数据和dom元素。在给定的代码片段中，使用 created() 函数来调用了 load 方法。
// 因此，在组件实例被创建后，vue 实例会自动调用 created() 钩子函数，并在其中执行了 this.load() 方法。也就是说，在组件被实例化之后需要请求数据并对页面进行渲染。created() 钩子通常被用于异步操作或者对一些初始的数据进行处理和赋值等工作。
  methods: {
    load(){
      request.get('/Fj/page', {
        params: this.params
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data.list
          this.total = res.data.total
        }
      })
    },
    load1(){
      request.get('/Fj/page1', {
        params: this.params
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data.list
          this.total = res.data.total
        }
      })
    },
    reset() {
      this.params = {
        pageNum: 1,
        pageSize: 8,
        room: '',
        type:''
      }
      this.load()
    },
    handleCurrentChange(pageNum) {
      // 点击分页按钮触发分页
      this.params.pageNum = pageNum
      this.load()
    },
    changeState(row) {
     request.put('/Fj/update', row).then(res => {
        if (res.code === '200') {
          this.$notify.success('操作成功')
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
  },
    del(id) {
      request.delete("/Fj/delete/" + id).then(res => {
        if (res.code === '200') {
          this.$notify.success('删除成功')
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    }




}}
</script>

<style scoped>

</style>