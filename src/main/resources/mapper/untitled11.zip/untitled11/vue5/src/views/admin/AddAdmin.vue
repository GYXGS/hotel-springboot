<template><div style=" width:80%">
  <el-form :inline="true" :rules="rules">
    <el-form-item label="username">
      <el-input placeholder="请输入账号" v-model="a.username">
      </el-input>
    </el-form-item>

    <el-form-item label="name">
    <el-input placeholder="请输入名字" v-model="a.name">
    </el-input>
  </el-form-item>
    <el-form-item label="phone">
      <el-input placeholder="请输入电话" v-model="a.phone">
      </el-input>
    </el-form-item>
    <el-form-item label="sex">
      <el-input placeholder="请输入性别" v-model="a.sex">
      </el-input>
    </el-form-item>
      <el-form-item label="card">
        <el-input placeholder="请输入身份证" v-model="a.card">
        </el-input>
      </el-form-item>
        <el-form-item label="position">
          <el-input placeholder="请输入职位" v-model="a.position">
          </el-input>
    </el-form-item>
    <el-form-item size="medium">

    </el-form-item>
  </el-form>
  <div style="text-align: center; margin-top: 30px">
    <el-button type="primary" @click="create">立即创建</el-button>
  </div>
</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "AddAdmin",data(){

      return {
        value: '',
        a:{
          username:'',
          name:'',
          phone:'',
          sex:'',
          position:'',
          card:'',



        }
      }

  },
  methods: {
    create(){
      request.put("/Admin/add",this.a).then(res=>{
      if(res.code==='200'){
        this.$notify.success("添加成功")
        this.$router.push('/add')
      }})

    }
  }

  }

</script>
<style>
.abc{
display: flex;
}
</style>
<style scoped>

</style>