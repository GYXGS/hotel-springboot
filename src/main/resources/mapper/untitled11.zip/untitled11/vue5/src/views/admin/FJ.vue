<template>
  <div style="width: 50% ">
<!--  <el-form-item label="封面" prop="cover">-->
<!--    <el-upload-->
<!--        class="avatar-uploader"-->
<!--        :action="'http://localhost:9090/api/book/file/upload?token=' + this.admin.token"-->
<!--        :show-file-list="false"-->
<!--        :on-success="handleCoverSuccess"-->
<!--    >-->
<!--      <img v-if="form.cover" :src="form.cover" class="avatar">-->
<!--      <i v-else class="el-icon-plus avatar-uploader-icon"></i>-->
<!--    </el-upload>-->
<!--  </el-form-item>-->

  <el-form :inline="true" :rules="rules" :model="fj" >
    <el-form-item label="房间类型">
      <el-select v-model="fj.type" placeholder="请选择" >
        <el-option
            v-for="item in type"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          <span style="float: left">{{ item.label }}</span>
          <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}</span>
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="房间号">
      <el-input placeholder="请输入" v-model="fj.room">
      </el-input>
    </el-form-item>

    <el-form-item label="费用">
    <el-input placeholder="请输入费用" v-model="fj.value">
    </el-input>
  </el-form-item>
    <el-form-item label="备注">
      <el-input placeholder="请输入" v-model="fj.mean">
      </el-input>
    </el-form-item>
    <el-form-item size="medium">

    </el-form-item>
  </el-form>
    <div style="text-align: center; margin-top: 30px">
      <el-button type="primary" @click="create">立即创建</el-button>
    </div>
</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "FJ",data(){

      return {
        type: [{
          value: '豪华单人房',
          label: '豪华单人房'
        }, {
          value: '豪华双人房',
          label: '豪华双人房'
        }, {
          value: '总统套房',
          label: '总统套房'
        },  ],
        // value: '',
        fj:{
          // room:'',
          // id:'',
          // value:'',
          // mean:'',
          // type:''

        },
        rules: {
          room: [
            { required: true, message: '请输入房间号', trigger: 'blur'},
            { min: 3, max: 10, message: '长度在3-10个字符', trigger: 'blur'}
          ],
      },
        fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}]

      }
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    create(){
      request.put("/Fj/add",this.fj).then(res=>{
      if(res.code==='200'){
        this.$notify.success("添加成功")
        this.$router.push('/FJ')

      }
      else{
        this.$notify.warning("房间号已经存在")
      }})

    }
  }

  }

</script>
<style>
/*.abc{*/
/*display: flex;*/
/*}*/
</style>
<style scoped>

</style>