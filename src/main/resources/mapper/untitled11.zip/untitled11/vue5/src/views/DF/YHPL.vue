<template>
  <div>
  <div style="width:400px;height:300px;border-radius: 10px;background-color:whitesmoke;margin: 150px auto;padding: 50px">
    <div style="margin:30px;text-align: center;font-weight: bold;font-size: 30px;color: dodgerblue">用户评论</div>
    <el-form :model="pl" status-icon  ref="ruleForm" >
      <el-form-item  prop="order1">
        <el-input placeholder="请输入订单号" prefix-icon="el-icon-user" size="medium" v-model="pl.order1"></el-input>
      </el-form-item>
      <el-form-item  prop="mean" >
        <el-input placeholder="请输入您的评论"  size="medium" v-model="pl.mean"></el-input>
      </el-form-item>
      <el-form-item  >
      <el-button style="width: 100%" size="medium" type="primary" @click="login">提交</el-button>
      </el-form-item>
    </el-form>
  </div>



  </div>
</template>

<script>


import request from "@/utils/request";
export default {
  name: 'HomeView',
data(){
  return {
pl:{
 order1:'',
  mean:''
},


  }},
  created() {
    const order1 = this.$route.query.order1
    request.get("/Pl1/" + order1).then(res => {
      this.pl = res.data
    })
  },
  methods:{
    login(){
      request.post('/Pl1/login',this.pl).then(res=>{
        if(res.code==='200'){
          this.$notify.success("验证成功");
          this.add();
        }
   else {
          this.$notify.error("订单号错误")
        }

      })
    },
add() {
    request.put("/Pl1/add", this.pl).then(res => {
      if (res.code === '200') {
        this.$notify.success("评论成功")
        this.$router.push('/YHPL')
      }
      else{
        this.$notify.error("请输入订单号")
      }
    }
    )
  }

}

}
</script>
