<template>
  <div>
    <!--    搜索-->
    <div >
      <el-input style="width: 240px" placeholder="请输入用户名" v-model="params.username"></el-input>
      <el-button style="margin-left: 5px" type="primary" @click="load"><i class="el-icon-search"></i> 搜索</el-button>
      <el-button style="margin-left: 5px" type="warning"@click="reset" ><i class="el-icon-refresh"></i> 重置</el-button>
    </div>
    <el-table  :data="tableData">
      <el-table-column prop="username" label="用户ID" >
      </el-table-column>
      <el-table-column prop="name" label="姓名">
      </el-table-column>
      <el-table-column prop="phone" label="手机号">
      </el-table-column>
      <el-table-column prop="sex" label="性别">
      </el-table-column>
      <el-table-column prop="position" label="职位">
      </el-table-column>
      <el-table-column prop="card" label="证件号">
      </el-table-column>
      <el-table-column prop="state" label="状态">
      </el-table-column>
      <el-table-column label="操作" width="270">
        <template v-slot="scope">
          <!--          scope.row 就是当前行数据-->
          <el-button type="primary" @click="$router.push('/updateAdmin?id=' + scope.row.id)">编辑</el-button>
          <el-popconfirm
              style="margin-left: 5px"
              title="您确定删除这行数据吗？"
              @confirm="del(scope.row.id)"
          >
            <el-button type="danger" slot="reference">删除</el-button>
          </el-popconfirm>
          <el-button style="margin-left: 5px" type="warning" @click="handleChangePass(scope.row)">修改密码</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog title="修改密码" :visible.sync="dialogFormVisible" width="30%">
      <el-form :model="form" label-width="100px" ref="formRef" :rules="rules">
        <el-form-item label="新密码" prop="newPass">
          <el-input v-model="form.newPass" autocomplete="off" show-password></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="savePass">确 定</el-button>
      </div>
    </el-dialog>
    <!--    分页-->
    <div style="margin-top: 20px">
      <el-pagination
          background
          :current-page="params.pageNum"
          :page-size="params.pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="handleCurrentChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import request from "@/utils/request";
import Cookies from 'js-cookie';
export default {
  name: "GLY",data(){
    return{
      admin: Cookies.get('Admin') ? JSON.parse(Cookies.get('Admin')) : {},
      tableData:[],
      total:0,
      params: {
        pageNum: 1,
        pageSize: 8,
        username: '',
      },
      dialogFormVisible: false,
      rules: {
        newPass: [
          {required: true, message: '请输入新密码', trigger: 'blur'},
          {min: 3, max: 10, message: '长度在3-10个字符', trigger: 'blur'}
        ]
      },
      form:{}
    }
},
  created() {
    this.load()
  },
//   created() 选项是 vue.js 组件中的一个生命周期钩子函数，在组件实例被创建并初始化后立即调用，这时候可以访问到数据和dom元素。在给定的代码片段中，使用 created() 函数来调用了 load 方法。
// 因此，在组件实例被创建后，vue 实例会自动调用 created() 钩子函数，并在其中执行了 this.load() 方法。也就是说，在组件被实例化之后需要请求数据并对页面进行渲染。created() 钩子通常被用于异步操作或者对一些初始的数据进行处理和赋值等工作。
  methods: {
    load(){
      request.get('/Admin/page', {
        params: this.params
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data.list
          this.total = res.data.total
        }
      })
    },
    reset() {
      this.params = {
        pageNum: 1,
        pageSize: 10,
        username: '',
      }
      this.load()
    },
    handleCurrentChange(pageNum) {
      // 点击分页按钮触发分页
      this.params.pageNum = pageNum
      this.load()
    },
    handleChangePass(row) {
      this.form = JSON.parse(JSON.stringify(row))
      this.dialogFormVisible = true
    },
    savePass() {
      this.$refs['formRef'].validate((valid) => {
        if (valid) {
          request.put('/Admin/password', this.form).then(res => {
            if (res.code === '200') {
              this.$notify.success("修改成功")
              if (this.form.id === this.admin.id) {   // 当前修改的用户id 等于当前登录的管理员id，那么修改成功之后需要重新登录
                Cookies.remove('Admin')
                this.$router.push('/')
              } else {
                this.load()
                this.dialogFormVisible = false
              }
            } else {
              this.$notify.error("修改失败")
            }
          })
        }
      })
    },
    del(id) {
      request.delete("/Admin/delete/" + id).then(res => {
        if (res.code === '200') {
          this.$notify.success('删除成功')
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    }
  }
}
</script>

<style scoped>

</style>