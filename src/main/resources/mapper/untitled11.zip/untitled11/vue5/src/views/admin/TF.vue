<template>
  <div>
    <!--    搜索-->
    <div >
      <el-input style="width: 240px" placeholder="请输入订单号" v-model="params.order1" ></el-input>
      <el-button style="margin-left: 5px" type="primary" @click="load"><i class="el-icon-search"></i> 搜索</el-button>
      <el-button style="margin-left: 5px" type="warning" @click="reset"><i class="el-icon-refresh"></i> 重置</el-button>
    </div>
          <el-table  :data="tableData" @row-click="handleClick">
            <el-table-column prop="name" label="用户名">
            </el-table-column>
            <el-table-column prop="order1" label="订单号" >
            </el-table-column>
            <el-table-column prop="room" label="房号" >
            </el-table-column>
            <el-table-column prop="value" label="费用">
            </el-table-column>
            <el-table-column prop="state" label="状态">
            </el-table-column>
            <el-table-column label="操作" width="230">
              <template v-slot="scope">
              <el-button type="primary" @click="updateState(),update(scope.row)">退房</el-button>
              </template>
            </el-table-column>
          </el-table>
    <!--    分页-->
    <div style="margin-top: 20px">
      <el-pagination
          background
          :current-page="params.pageNum"
          :page-size="params.pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="handleCurrentChange"
      >
      </el-pagination>
    </div>
</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "U_information",

  data(){

    return {
      tableData:[],
      total:0,
      params:{
        order1:'',
        pageNum: 1,
        pageSize: 8
      }
    }
  },
  created() {
    this.load()

  },
  methods: {
    handleClick(row) {
      this.currentRoom = row.room;
    },
    // someFunction() {
    //   this.$refs.myComponent.update(row)
    // },
    update(row){
     {
      request.put('/Dd/update',row).then(res => {
        if (res.code === '200') {

          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    }},
    updateState(){
      if (!this.currentRoom) {
        // 没有选中行，不进行更新操作
        return;
      }
      request.put('/Fj/updateState1',{ room: this.currentRoom }).then(res => {
        if (res.code === '200') {
          this.$notify.success('操作成功')
// this.someFunction()
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    },
    handleCurrentChange(pageNum) {
      // 点击分页按钮触发分页
      this.params.pageNum = pageNum
      this.load()
    },
    load() {
      request.get('/Dd/page', {
        params: this.params
      }).then(res => {
        if (res.code === '200') {
          this.tableData = res.data.list
          this.total = res.data.total
        }
      })
    },
    reset() {
      this.params = {
        pageNum: 1,
        pageSize: 10,
        id: '',
      }
      this.load()
    },
  }
}
</script>

<style scoped>

</style>