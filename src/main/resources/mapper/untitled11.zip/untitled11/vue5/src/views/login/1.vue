<template>
  <div style="width: 80%">
    <div style="margin-bottom: 30px">订单</div>
    <el-form :inline="true" :model="form" label-width="100px" :rules="rules" >
      <el-form-item label="房名字" prop="name">
        <el-input v-model="form.name" ></el-input>
      </el-form-item>
      <el-form-item label="房间类型" prop="type">
        <el-input v-model="form.type" placeholder="请输入房间类型"></el-input>
      </el-form-item>
      <el-form-item label="房号" prop="room">
        <el-input v-model="form.room" placeholder="请输入房号" ref="roomInput"></el-input>
      </el-form-item>
      <el-form-item label="订单号" prop="order1">
        <el-input v-model="form.order1" placeholder="请输入订单号"></el-input>
      </el-form-item>
      <el-form-item label="价格" prop="value">
        <el-input v-model="form.value" placeholder="请输入价格"></el-input>
      </el-form-item>
    </el-form>

    <div style="text-align: center; margin-top: 30px">
      <el-button type="primary" v-if="form.order1" @click="save(),updateState()" size="medium">提交</el-button>
    </div>
  </div>
</template>

<script>
import request from "@/utils/request";



export default {
  name: '1',
  data() {
    return {
      form: {
        room:''
      },
      rules: {
        order1: [
          { required: true, message: '请输入订单号', trigger: 'blur'},
        ], room: [
          { required: true, message: '请输入房间号', trigger: 'blur'},

        ]
      },
    }
  },
  created() {
    const id = this.$route.query.id
    request.get("/Df/" + id).then(res => {
      this.form = res.data

    })
    // const room = this.$route.query.room
    // request.get("/Df/" + room).then(res => {
    //       this.form = res.data
    // })
  },
  methods: {
  save() {
      request.put('/Dd/add', this.form).then(res => {
        if (res.code === '200') {
          this.$router.push("/TF")
        } else {
          this.$notify.error(res.msg)
        }
      })
    },
    updateState(){
      request.put('/Fj/updateState',{ room: this.$refs.roomInput.$refs.input.value }).then(res => {
        if (res.code === '200') {
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    },

  }
}

</script>

