<template>
  <div>
    <!--    搜索-->
    <div >
      <el-input style="width: 240px" placeholder="请输入身份证" v-model="params.card"></el-input>
      <el-button style="margin-left: 5px" type="primary" @click="load"><i class="el-icon-search"></i> 搜索</el-button>
      <el-button style="margin-left: 5px" type="warning" @click="reset" ><i class="el-icon-refresh"></i> 重置</el-button>
      <el-button style="margin-left: 5px" type="primary"  @click="$router.push('/addYd')" >添加订单</el-button>
    </div>
<!--    data="tableData"是一个用于绑定数据的指令（Directive）。-->
<!--    其中，tableData是定义在组件（Component）中的数据对象，通过将其与模板中的 data属性绑定来实现将数据渲染到页面上-->
    <el-table  :data="tableData" >
      <el-table-column prop="name" label="姓名" >
      </el-table-column>
      <el-table-column prop="value" label="费用">
      </el-table-column>
      <el-table-column prop="type" label="房间类型">
      </el-table-column>
<!--      <el-table-column prop="time" label="时间">-->
<!--      </el-table-column>-->
      <el-table-column prop="address" label="备注">
      </el-table-column>
      <el-table-column prop="card" label="证件号">
      </el-table-column>
      <el-table-column prop="phone" label="电话">
      </el-table-column>
      <el-table-column prop="number" label="人数">
      </el-table-column>
      <el-table-column prop="state" label="状态">
<!--        <div>-->
<!--          <el-tag >{{ state }}</el-tag>-->
<!--        </div>-->
      </el-table-column>
      <el-table-column label="操作" width="230">
        <template v-slot="scope">
        <el-button  type="warning"     @click="update(scope.row), $router.push('/1?id=' + scope.row.id)" >转为订单</el-button>
        <el-popconfirm
            style="margin-left: 5px"
            title="您确定取消这个订单吗？"
            @confirm="del(scope.row.id)"
        >
          <el-button type="danger" slot="reference">删除</el-button>
        </el-popconfirm>
        </template>
      </el-table-column>

    </el-table>
    <el-dialog title="选择房间" :visible.sync="dialogFormVisible" width="100%">
      <div slot="footer" class="dialog-footer">
          <el-form :inline="true"  ref="ruleForm"  :rules="rules">
        <el-form-item label="房间号" prop="room">
<!--          <el-select v-model="form.room" filterable placeholder="请选择" >-->
<!--            <el-select v-model="value" clearable placeholder="请选择">-->
<!--              <el-option-->
<!--                  v-for="item in options"-->
<!--                  :key="item.value"-->
<!--                  :label="item.label"-->
<!--                  :value="item.value">-->
<!--              </el-option>-->
<!--            </el-select>-->
<!--            <el-option>-->
<!--              <ul >-->
<!--                <li v-for="item in rooms" :key="item.id" :label="item.room" :value="item.room">-->
<!--                  {{ item.id }}-->
<!--                </li>-->
<!--              </ul>-->
<!--            </el-option>-->
<!--          </el-select>-->
        </el-form-item>
          </el-form>

        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" >确 定</el-button>
      </div>
    </el-dialog>
    <!--    分页-->
    <div style="margin-top: 20px">
      <el-pagination
          background
          :current-page="params.pageNum"
          :page-size="params.pageSize"
          :total="total"
          layout="prev, pager, next"
          @current-change="handleCurrentChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
import request from "@/utils/request";
export default {
  name: "YD",
  data(){

    return{
      select: '',
      tableData:[],
      total:0,
      params: {
        pageNum: 1,
        pageSize: 8,
        card: '',
      },
      form: {},
      rules: {
        room: []},
rooms:[],

      dialogFormVisible: false,
    }
    },
  created() {
    request.get('/Fj/list').then(res => {
      this.rooms = res.data
    })
    // const id = this.$route.query.id
    // request.get("/Df/" + id).then(res => {
    //   this.form = res.data
    // })
    this.load()

  },
//   created() 选项是 vue.js 组件中的一个生命周期钩子函数，在组件实例被创建并初始化后立即调用，这时候可以访问到数据和dom元素。在给定的代码片段中，使用 created() 函数来调用了 load 方法。
// 因此，在组件实例被创建后，vue 实例会自动调用 created() 钩子函数，并在其中执行了 this.load() 方法。也就是说，在组件被实例化之后需要请求数据并对页面进行渲染。created() 钩子通常被用于异步操作或者对一些初始的数据进行处理和赋值等工作。
methods: {
  load(){
    request.get('/Df/page', {
      params: this.params
    }).then(res => {
      if (res.code === '200') {
        this.tableData = res.data.list
        this.total = res.data.total
      }
    })
  },
  reset() {
    this.params = {
      pageNum: 1,
      pageSize: 10,
      card: '',
    }
    this.load()
  },
  handleCurrentChange(pageNum) {
    // 点击分页按钮触发分页
    this.params.pageNum = pageNum
    this.load()
  },
  // fetchDataFromDatabase() {
  //   request.get('/Df/page').then(res => {
  //     if (res.code==='200') {
  //       this.state=res.data.state
  //       this.tagType = 'warning'
  //     // } else {
  //     //   this.value1=res.data.state
  //     //   this.tagType = 'primary'
  //     }
  //   })
  //
  // },
  update(row){
    request.put('/Df/update',row).then(res => {
      if (res.code === '200') {

        this.load()
      } else {
        this.$notify.error(res.msg)
      }
    })
  },
  del(id) {
    request.delete("/Df/delete/" + id).then(res => {
      if (res.code === '200') {
        this.$notify.success('删除成功')
        this.load()
      } else {
        this.$notify.error(res.msg)
      }
    })
  },
  // handleChange(row) {
  //   this.form = JSON.parse(JSON.stringify(row))
  //   this.dialogFormVisible = true
  // },
  // selDf() {
  //   const room = this.rooms.find(v => v.room === this.form.room)
  //   request.get('/Df/' + room.id).then(res => {
  //     this.$set(this.form, 'room', res.data.room)
  //     // this.form.userPhone = res.data.phone
  //     // this.form.account = res.data.account
  //   })
  // }

}




}
</script>

<style scoped>

</style>