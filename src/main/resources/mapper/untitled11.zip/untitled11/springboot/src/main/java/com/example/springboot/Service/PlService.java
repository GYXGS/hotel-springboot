package com.example.springboot.Service;

import com.example.springboot.DTO.PlDTO;
import com.example.springboot.Request.BaseRequest;
import com.example.springboot.Request.PlRequest;
import com.example.springboot.Request.PlRequest;
import com.example.springboot.entity.Pl;
import com.example.springboot.mapper.PlMapper;
import com.example.springboot.mapper.PlMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class PlService implements IPlService {
    @Autowired
    PlMapper plMapper;
    @Override
    public PlDTO pl(PlRequest plRequest){


        try {
            Pl pl = plMapper.getByOrder(plRequest);
            PlDTO plDTO=new PlDTO();
            BeanUtils.copyProperties(pl,plDTO);
            return  plDTO;
        } catch (Exception e) {
            log.error("登录出现异常",e);
            return null;
        }

    }

    public void add(Pl pl) {plMapper.addByOrder(pl) ;}
    @Override
    public PageInfo<Pl> page(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(), baseRequest.getPageSize());
        List<Pl> Pls = plMapper.listByCondition(baseRequest);
        return new PageInfo<>(Pls);
    }
    @Override
    public void deleteById(Integer id) {
        plMapper.deleteById(id);
    }
}
