package com.example.springboot.entity;

import lombok.Data;

@Data
public class Df {
    public  String name;
    public String phone;
    public String type;
    public String address;
    public String card;
    public String value;
    public String number;
    public String state;
    public  int id;

}
