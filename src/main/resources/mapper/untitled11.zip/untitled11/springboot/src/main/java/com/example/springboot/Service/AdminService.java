package com.example.springboot.Service;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.example.springboot.Request.BaseRequest;
import com.example.springboot.Request.PasswordRequest;
import com.example.springboot.entity.Admin;
import com.example.springboot.DTO.LoginDTO;
import com.example.springboot.Request.LoginRequest;
import com.example.springboot.exception.ServiceException;
import com.example.springboot.mapper.AdminMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class AdminService implements IAdminService{
    @Autowired
    AdminMapper adminMapper;
    private static final String DEFAULT_PASS = "123";
    private static final String PASS_SALT = "DL";
    public List<Admin> list(){ return adminMapper.list(); }
    @Override
    public PageInfo<Admin> page(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(), baseRequest.getPageSize());
        List<Admin> admins = adminMapper.listByCondition(baseRequest);
        return new PageInfo<>(admins);
    }
    @Override
    public LoginDTO login(LoginRequest loginRequest){


        try {
            Admin admin = adminMapper.getByUsernameAndPassword(loginRequest);
            LoginDTO loginDTO=new LoginDTO();
            BeanUtils.copyProperties(admin,loginDTO);
            return  loginDTO;
        } catch (Exception e) {
            log.error("登录出现异常",e);
            return null;
        }

    }
    @Override
    public void deleteById(Integer id) {
        adminMapper.deleteById(id);
    }
    public void add(Admin admin) {adminMapper.add(admin) ;}

    public void update(Admin admin) {adminMapper.updateById(admin);}
    @Override
    public Admin getById(Integer id) {
        return adminMapper.getById(id);
    }

    @Override
    public void changePass(PasswordRequest request) {
        // 注意 你要对新的密码进行加密
        request.setNewPass(securePass(request.getNewPass()));
        int count = adminMapper.updatePassword(request);
        if (count <= 0) {
            throw new ServiceException("修改密码失败");
        }
    }
    private String securePass(String password) {
        return SecureUtil.md5(password + PASS_SALT);
    }
    @Override
    public void save(Admin obj) {
        // 默认密码 123
        if (StrUtil.isBlank(obj.getPassword())) {
            obj.setPassword(DEFAULT_PASS);
        }
        obj.setPassword(securePass(obj.getPassword()));  // 设置md5加密，加盐
        try {
            adminMapper.save(obj);
        } catch (DuplicateKeyException e) {
            log.error("数据插入失败， username:{}", obj.getUsername(), e);
            throw new ServiceException("用户名重复");
        }
    }
}
