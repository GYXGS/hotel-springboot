package com.example.springboot.entity;

import com.example.springboot.Request.FjPageRequest;
import com.example.springboot.Service.FjService;
import com.example.springboot.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/Fj")
@Service
public class FjController {
    @Autowired
    FjService fjService;
    @PutMapping("/add")
    public Result add(@RequestBody Fj fj) {
        fjService.add(fj);
    return Result.success();
    }
    @GetMapping("/list")
    public List<Fj> list(){
        return fjService.list();
    }
    @GetMapping("/page")
    public Result page(FjPageRequest fjPageRequest) {
        return Result.success(fjService.page(fjPageRequest));
    }
    @GetMapping("/page1")
    public Result page1(FjPageRequest fjPageRequest) {
        return Result.success(fjService.page1(fjPageRequest));
    }
    @PutMapping("/update")
    public Result update(@RequestBody Fj obj) {
        fjService.update(obj);
        return Result.success();
    }
    @PutMapping("/updateState")
    public Result updateState(@RequestBody Fj obj) {
        fjService.updateState(obj);
        return Result.success();
    }
    @PutMapping("/updateState1")
    public Result updateState1(@RequestBody Fj obj) {
        fjService.updateState1(obj);
        return Result.success();
    }
    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id) {
        Fj obj = fjService.getById(id);
        return Result.success(obj);
    }
    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable Integer id) {
        fjService.deleteById(id);
        return Result.success();
    }
    //    @PutMapping("/add")
//    public Result add(@RequestBody ClaIn claIn){
//        claInService.add(claIn);
//        return  Result.success();
//    }
}
