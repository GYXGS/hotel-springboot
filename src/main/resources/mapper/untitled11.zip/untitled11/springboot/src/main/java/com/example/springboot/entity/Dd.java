package com.example.springboot.entity;

import lombok.Data;

@Data
public class Dd {
    private  String order1;
    private String name;
    private String state;
    private String room;
private Integer id;
private String type;
private  String value;
}
