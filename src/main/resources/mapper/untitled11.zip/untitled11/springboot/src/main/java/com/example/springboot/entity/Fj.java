package com.example.springboot.entity;

import lombok.Data;

@Data
public class Fj {
    public int id;
    public String type;
    public String value;
    public String mean;
public Boolean state;
private String room;
}
