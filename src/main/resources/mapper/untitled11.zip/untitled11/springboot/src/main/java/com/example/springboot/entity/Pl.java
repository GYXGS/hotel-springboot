package com.example.springboot.entity;

import lombok.Data;

@Data
public class Pl {
    public int id;
    public String mean;
    public String order1;
}
