package com.example.springboot.Request;

import lombok.Data;

@Data
public class PlPageRequest extends BaseRequest{
    private String order1;
}
