package com.example.springboot.Service;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.entity.Dd;
import com.github.pagehelper.PageInfo;

import java.awt.print.Book;
import java.util.List;


public interface IDdService {
    void add(Dd dd);
    PageInfo<Dd> page(BaseRequest baseRequest);
List<Dd> list();
    Dd getById(Integer id);
    void update(Dd obj);
    void deleteById(Integer id);}

