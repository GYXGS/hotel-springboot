package com.example.springboot.entity;
import lombok.Data;
@Data
public class Admin {
    public String username;
    public String password;
    public String name;
    public String card;
    public String sex;
    public String phone;
    public String position;
    public String state;
public int id;

}
