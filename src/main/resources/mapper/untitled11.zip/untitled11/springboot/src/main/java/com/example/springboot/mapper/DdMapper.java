package com.example.springboot.mapper;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.entity.Dd;
import org.apache.ibatis.annotations.Mapper;

import java.awt.print.Book;
import java.util.List;

@Mapper
public interface DdMapper {

    void add(Dd dd);


    List<Dd> list();
    List<Dd> listByCondition(BaseRequest baseRequest);
    void updateById(Dd user);
    Dd getById(Integer id);
    void deleteById(Integer id);
}
