package com.example.springboot.entity;

import com.example.springboot.DTO.LoginDTO;
import com.example.springboot.DTO.PlDTO;
import com.example.springboot.Request.AdminPageRequest;
import com.example.springboot.Request.LoginRequest;
import com.example.springboot.Request.PlPageRequest;
import com.example.springboot.Request.PlRequest;
import com.example.springboot.Service.AdminService;
import com.example.springboot.Service.PlService;
import com.example.springboot.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
//当在使用Spring框架创建Web应用程序时，@ CrossOrigin注释可以帮助您处理跨域请求。如果您的前端和后端代码位于不同的服务器上，则需要通过添加此注释来允许跨域请求。
//        它是一个用于授权远程客户端访问资源的方便注释，并支持跨域请求。 要使用此注释，请将其声明在Spring REST控制器的顶部（如@RestController）。
@RequestMapping("/Pl1")
@Service
public class PlController {
    @Autowired
    PlService plService;
    @PostMapping("/login")
    public Result login(@RequestBody PlRequest plRequest) {

        PlDTO pl = plService.pl(plRequest);
        if (pl == null) {
            return Result.error("订单号错误");
        }
        return Result.success(pl);
    }
    @PutMapping("/add")
//    @RequestBody接受前端传递给后端的字符串
    public Result add(@RequestBody Pl obj) {
        plService.add(obj);
        return Result.success();
    }
    @GetMapping("/page")
    public Result page(PlPageRequest plPageRequest) {
        return Result.success(plService.page(plPageRequest));
    }
    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable Integer id) {
        plService.deleteById(id);
        return Result.success();
    }
}
