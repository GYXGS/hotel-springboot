package com.example.springboot.Request;
import lombok.Data;

@Data
public class PlRequest {
    private String order1;
    private String mean;

}
