package com.example.springboot.Request;

import lombok.Data;

@Data
public class AdminPageRequest extends BaseRequest{
    private String username;
}
