package com.example.springboot.Service;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.entity.Df;
import com.example.springboot.entity.Fj;
import com.example.springboot.mapper.DfMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DfService implements IDfService{
    @Autowired
    DfMapper dfMapper;
    @Override
    public void add(Df df){dfMapper.add(df);}
    public List<Df> list(){return dfMapper.list();}
@Override
public PageInfo<Df> page(BaseRequest baseRequest) {
    PageHelper.startPage(baseRequest.getPageNum(), baseRequest.getPageSize());
    List<Df> dfs = dfMapper.listByCondition(baseRequest);
    return new PageInfo<>(dfs);
}
    @Override
    public void update(Df user) {
//        user.setUpdatetime(new Date());
        dfMapper.updateById(user);
    }
    @Override
    public Df getById(Integer id) {
        return dfMapper.getById(id);
    }
    @Override
    public void deleteById(Integer id) {
        dfMapper.deleteById(id);
    }
}
