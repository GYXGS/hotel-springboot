package com.example.springboot.mapper;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.entity.Df;
import com.example.springboot.entity.Fj;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DfMapper {

    void add(Df df);


    List<Df> list();
    List<Df> listByCondition(BaseRequest baseRequest);
    void updateById(Df user);
    Df getById(Integer id);
    void deleteById(Integer id);
}
