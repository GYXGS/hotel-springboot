package com.example.springboot.Request;

import lombok.Data;

@Data
public class DdPageRequest extends BaseRequest{
    private String order1;



}
