package com.example.springboot.Service;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.entity.Fj;
import com.example.springboot.entity.Fj;
import com.example.springboot.mapper.FjMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FjService implements IFjService{
    @Autowired
    FjMapper fjMapper;
   @Override
    public void add(Fj fj){fjMapper.add(fj);}
    public List<Fj> list(){return fjMapper.list();}
    @Override
    public PageInfo<Fj> page(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(), baseRequest.getPageSize());
        List<Fj> fjs = fjMapper.listByCondition(baseRequest);
        return new PageInfo<>(fjs);
    }
    public PageInfo<Fj> page1(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(), baseRequest.getPageSize());
        List<Fj> fjs = fjMapper.listByCondition1(baseRequest);
        return new PageInfo<>(fjs);
    }

    @Override
    public void update(Fj user) {
//        user.setUpdatetime(new Date());
        fjMapper.updateById(user);
    }
    @Override
    public void updateState(Fj user) {
//        user.setUpdatetime(new Date());
        fjMapper.updateByState(user);
    }  @Override
    public void updateState1(Fj user) {
//        user.setUpdatetime(new Date());
        fjMapper.updateByState1(user);
    }

    @Override
    public Fj getById(Integer id) {
        return fjMapper.getById(id);
    }
    @Override
    public void deleteById(Integer id) {
        fjMapper.deleteById(id);
    }
}

