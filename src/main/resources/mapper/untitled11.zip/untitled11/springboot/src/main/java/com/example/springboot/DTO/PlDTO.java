package com.example.springboot.DTO;
import lombok.Data;

@Data
public class PlDTO {
    private String mean;
}
