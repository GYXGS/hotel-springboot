package com.example.springboot.DTO;
import lombok.Data;
@Data
public class LoginDTO {
    private String username;
}
