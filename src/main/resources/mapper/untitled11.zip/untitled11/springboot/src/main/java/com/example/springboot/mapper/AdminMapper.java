package com.example.springboot.mapper;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.Request.LoginRequest;
import com.example.springboot.Request.PasswordRequest;
import com.example.springboot.entity.Df;
import com.example.springboot.entity.Fj;
import org.apache.ibatis.annotations.Mapper;
import com.example.springboot.entity.Admin;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;

import java.util.List;


@Mapper
public interface AdminMapper {
   Admin getByUsernameAndPassword(LoginRequest loginRequest);
   List<Admin> list();
   List<Admin> listByCondition(BaseRequest baseRequest);

    void add(Admin admin);
    void updateById(Admin admin);
    Admin getById(Integer id);
    int updatePassword(PasswordRequest request);
    void save(Admin obj);

    void deleteById(Integer id);
}
