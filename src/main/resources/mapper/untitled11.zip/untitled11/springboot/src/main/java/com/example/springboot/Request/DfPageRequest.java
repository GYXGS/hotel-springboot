package com.example.springboot.Request;

import lombok.Data;

@Data
public class DfPageRequest extends BaseRequest{
    private String card;



}
