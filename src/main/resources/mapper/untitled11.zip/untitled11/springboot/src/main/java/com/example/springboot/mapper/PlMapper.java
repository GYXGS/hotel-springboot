package com.example.springboot.mapper;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.Request.PlRequest;
import com.example.springboot.entity.Pl;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PlMapper {
    Pl getByOrder(PlRequest plRequest);
    void addByOrder(Pl pl);
    List<Pl> listByCondition(BaseRequest baseRequest);
    void deleteById(Integer id);
}
