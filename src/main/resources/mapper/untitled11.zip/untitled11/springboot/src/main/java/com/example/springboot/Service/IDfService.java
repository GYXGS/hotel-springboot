package com.example.springboot.Service;

import com.example.springboot.Request.BaseRequest;
import com.example.springboot.entity.Df;
import com.example.springboot.entity.Fj;
import com.example.springboot.mapper.DfMapper;
import com.github.pagehelper.PageInfo;

import java.util.List;


public interface IDfService {
    void add(Df df);
    PageInfo<Df> page(BaseRequest baseRequest);
List<Df> list();
    Df getById(Integer id);
    void update(Df obj);
    void deleteById(Integer id);
}
